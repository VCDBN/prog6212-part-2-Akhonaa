﻿namespace ClassLibrary2
{
    public class Module
    {
        public string? Code { get; set; }
        public string? Name { get; set; }
        public int Credits { get; set; }
        public int ClassHoursPerWeek { get; set; }

        public int RecordedHours { get; set; }
        public string? Username { get; set; }
        public string? Password { get; set; }
        public int ModuleID { get; set; }

        public DateTime StartDate { get; set; }

    }
}