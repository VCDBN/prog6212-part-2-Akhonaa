use Prog_P2_DB;

drop table ModuleInfo;

create table UserDetails
(
Username varchar(80) primary key not null,
Password varchar(150) not null
);

create table ModuleInfo
(
Code varchar(10),
Name varchar(50) primary key not null,
Credits int,
ClassHoursPerWeek int,
Username varchar(80),
RecordedHours int,
StartDate datetime,
foreign key (Username) references UserDetails(Username)
);

select * from UserDetails;
select * from ModuleInfo;
