﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;

namespace PROG6212_POE_P2
{
    public class ConnectionClass
    {
        public const string connectString = "Data Source=lab000000\\SQLEXPRESS;Initial Catalog=Prog_P2_DB;Integrated Security=True";
    }
}
