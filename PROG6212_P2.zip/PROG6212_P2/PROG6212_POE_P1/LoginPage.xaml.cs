﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Data.SqlClient;


namespace PROG6212_POE_P2
{
    /// <summary>
    /// Interaction logic for LoginPage.xaml
    /// </summary>
    public partial class LoginPage : Window
    {
        public LoginPage()
        {
            InitializeComponent();
        }

        private void SignUpUsernameTextBox_TextChanged(object sender, TextChangedEventArgs e)
        {

        }

        private void LoginButton_Click(object sender, RoutedEventArgs e)
        {
            string username = LoginUsernameTextBox.Text;
            string password = LoginPasswordBox.Password;

            string hashedPassword = HashPassword(password);

            using (SqlConnection connection = new SqlConnection(ConnectionClass.connectString))
            {
                connection.Open();
                string query = $"SELECT * FROM UserDetails WHERE username = '{username}' AND password = '{hashedPassword}'";
                SqlCommand command = new SqlCommand(query, connection);
                SqlDataReader reader = command.ExecuteReader();

                if (reader.HasRows)
                {
                    reader.Close();
                    MainWindow mainWindow = new MainWindow(username);
                    mainWindow.Show();
                    this.Close();
                }
                else
                {
                    reader.Close();
                    MessageBox.Show("Invalid username or password. Please try again.");
                }
            }
        }

        private void SignUpButton_Click(object sender, RoutedEventArgs e)
        {
            string username = SignUpUsernameTextBox.Text;
            string password = SignUpPasswordBox.Password;

            string hashedPassword = HashPassword(password);

            using (SqlConnection connection = new SqlConnection(ConnectionClass.connectString))
            {
                connection.Open();
                string query = $"INSERT INTO UserDetails (username, password) VALUES ('{username}', '{hashedPassword}')";
                SqlCommand command = new SqlCommand(query, connection);
                command.ExecuteNonQuery();
            }

            MessageBox.Show("Sign up successful! You can now log in.");
        }

        private void LoginUsernameTextBox_TextChanged(object sender, TextChangedEventArgs e)
        {

        }

        private string HashPassword(string password)
        {
            
            return password;
        }
    }
}
