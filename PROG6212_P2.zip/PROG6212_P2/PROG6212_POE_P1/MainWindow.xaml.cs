﻿using System;
using System.Collections.Generic;
using System.Windows;
using System.Linq;
using System.Windows.Controls;
using ClassLibrary2;
using System.Data.SqlClient;


namespace PROG6212_POE_P2
{
    public partial class MainWindow : Window
    {
        private List<Module> modules = new List<Module>();
        private int numberOfWeeks;
        private DateTime startDate;
        private string loggedInUsername;

        public MainWindow() : this(string.Empty)
        {
            InitializeComponent();
            InitializeModulesComboBox();
        }

        public MainWindow(string username) 
        {
            InitializeComponent();
            loggedInUsername = username;
            InitializeModulesComboBox();
        }

        private void InitializeModulesComboBox()
        {
            using (SqlConnection connection = new SqlConnection(ConnectionClass.connectString))
            {
                connection.Open();
                string query = $"SELECT * FROM ModuleInfo WHERE username = '{loggedInUsername}'";
                SqlCommand command = new SqlCommand(query, connection);
                SqlDataReader reader = command.ExecuteReader();

                while (reader.Read())
                {
                    Module module = new Module
                    {

                        Code = reader.GetString(0),
                        Name = reader.GetString(1),
                        Credits = reader.GetInt32(2),
                        ClassHoursPerWeek = reader.GetInt32(3),
                        Username = reader.GetString(4),
                        RecordedHours = reader.GetInt32(5),
                       StartDate = reader.GetDateTime(6),
                        
                    };

                    modules.Add(module);
                }

                ModuleComboBox.ItemsSource = modules;
            }
        }

        private void AddModuleButton_Click(object sender, RoutedEventArgs e)
        {
            string code = ModuleCodeTextBox.Text;
            int credits = int.Parse(ModuleCreditsTextBox.Text);
            int classHours = int.Parse(ModuleClassHoursTextBox.Text);
            string modName = ModuleNameTextBox.Text;
            DateTime startDate = DatePicker.SelectedDate ?? DateTime.Now;

            using (SqlConnection connection = new SqlConnection(ConnectionClass.connectString))
            {
                connection.Open();
                string query = $"INSERT INTO ModuleInfo (Code, Name, Credits, ClassHoursPerWeek, Username, RecordedHours, StartDate) " +
                               $"VALUES ('{code}', '{modName}',{credits}, {classHours}, '{loggedInUsername}', 0, '{startDate.ToString("yyyy-MM-dd")}')";
                SqlCommand command = new SqlCommand(query, connection);
                command.ExecuteNonQuery();
            }

            ClearModuleFields();
            InitializeModulesComboBox();
        }

        private void ModuleComboBox_SelectionChanged(object sender, System.Windows.Controls.SelectionChangedEventArgs e)
        {
            if (ModuleComboBox.SelectedItem is Module selectedModule)
            {
                SelectedModuleTextBox.Text = $"Code: {selectedModule.Code}\n" +
                                             $"Name: {selectedModule.Name}\n" +
                                             $"Credits: {selectedModule.Credits}\n" +
                                             $"Class Hours/Week: {selectedModule.ClassHoursPerWeek}\n";

                CalculateSelfStudyHours(selectedModule);
            }
        }

        private void CalculateSelfStudyHours(Module module)
        {
            if (numberOfWeeks > 0 && startDate != default(DateTime))
            {
                DateTime currentDate = DateTime.Now;
                int currentWeek = (int)Math.Ceiling(currentDate.Subtract(startDate).TotalDays / 7);
                int selfStudyHours = (module.Credits * 10) / numberOfWeeks - module.ClassHoursPerWeek;

                SelectedModuleTextBox.Text += $"Self-Study Hours/Week: {selfStudyHours}\n" +
                                              $"Number of Weeks: {numberOfWeeks}\n" +
                                              $"Start Date: {startDate.ToShortDateString()}\n" +
                                              $"Current Week: {currentWeek}\n";
            }
        }

        private void ClearModuleFields()
        {
            ModuleCodeTextBox.Clear();
            ModuleNameTextBox.Clear();
            ModuleCreditsTextBox.Clear();
            ModuleClassHoursTextBox.Clear();
        }

        private void SetSemesterParametersButton_Click(object sender, RoutedEventArgs e)
        {
            if (int.TryParse(WeeksTextBox.Text, out int weeks) && DatePicker.SelectedDate.HasValue)
            {
                numberOfWeeks = weeks;
                startDate = DatePicker.SelectedDate.Value;
            }
            else
            {
                MessageBox.Show("Please enter valid semester information.");
            }
        }
    }
}
